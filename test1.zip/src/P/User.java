package P;

public class User {
    private int ID;
    private String Upassword1 ;
    private String Uname;
    private int Uage ;
    private String Usex ;
    private String Umarjor ;
    private String Uphone;
    private String Upassword2;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getUpassword1() {
        return Upassword1;
    }

    public void setUpassword1(String upassword1) {
        Upassword1 = upassword1;
    }

    public String getUname() {
        return Uname;
    }

    public void setUname(String uname) {
        Uname = uname;
    }

    public int getUage() {
        return Uage;
    }

    public void setUage(int uage) {
        Uage = uage;
    }

    public String getUsex() {
        return Usex;
    }

    public void setUsex(String usex) {
        Usex = usex;
    }

    public String getUmarjor() {
        return Umarjor;
    }

    public void setUmarjor(String umarjor) {
        Umarjor = umarjor;
    }

    public String getUphone() {
        return Uphone;
    }

    public void setUphone(String uphone) {
        Uphone = uphone;
    }

    public String getUpassword2() {
        return Upassword2;
    }

    public void setUpassword2(String upassword2) {
        Upassword2 = upassword2;
    }
}
