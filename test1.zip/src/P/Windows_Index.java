package P;

import javax.swing.*;

public class Windows_Index extends JFrame {
    public static void main(String[] args){

    }
}
