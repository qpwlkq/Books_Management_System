package P;

import java.sql.SQLException;

public class test1 {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        /*

        Boook b = new Boook();
        b.setBauthor("秦鹏");
        b.setBname("资本论");
        b.setBnumber(20);
        b.setBpress("人民没电出版社");
        b.setBpublish(2020);
        b.setISBN("123456780");
        b.setKind("abc");
        //Book_Add c = new Book_Add();
        Book_Add.Insert(b);
        System.out.println("AMD YES!");
        */
    }
}
